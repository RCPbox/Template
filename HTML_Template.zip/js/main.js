/*! main.js */
(function(global, $, undefined){
	'use strict';

})(window, window.jQuery);